
# systemctl restart hiddify-panel.service
# systemctl status hiddify-panel.service