systemctl kill ss-v2ray.service
systemctl kill ss-faketls.service

systemctl disable ss-v2ray.service
systemctl disable ss-faketls.service