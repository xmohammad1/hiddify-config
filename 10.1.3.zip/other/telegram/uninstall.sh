
systemctl kill mtproxy
systemctl disable mtproxy
systemctl kill mtproto-proxy
systemctl disable mtproto-proxy
