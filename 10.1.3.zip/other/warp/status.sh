cd $( dirname -- "$0"; )
cd wireguard&&bash status.sh
