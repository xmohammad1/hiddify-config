
systemctl stop hiddify-warp
systemctl disable hiddify-warp
