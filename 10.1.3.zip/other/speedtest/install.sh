head -c 30m </dev/urandom >downloading
