systemctl kill v2ray
systemctl disable v2ray